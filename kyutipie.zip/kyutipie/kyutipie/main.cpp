//
//  main.cpp
//  kyutipie
//
//  Created by Abdul Azis Al Ayubbi on 6/01/23.
//

#include "kyutipie.hpp"

int main(int argc, const char * argv[]) {
    bool stillChoose = true;
    Queue prioritasTinggi, prioritasRendah, prioritasSedang;
    prioritasTinggi = createQueue();
    prioritasRendah = createQueue();
    prioritasSedang = createQueue();
    int jumlahTinggi = 0;
    int jumlahSedang = 0;
    int jumlahRendah = 0;

    while(stillChoose) {
        cout << "Selamat datang dalam aplikasi penjadwalan LORD RANGGA" << endl;
        cout << "Terdapat beberapa pilihan yang bisa kamu pilih, pilih salah satu diantara pilihan di bawah ini: " << endl;
        cout << "1. Masukkan jadwal lord rangga: "  << endl;
        cout << "2. Melihat jadwal lord rangga: " << endl;
        cout << "3. Melihat total turn around time dan total waiting time dari jadwal kegiatan lord rangga: " << endl;
        cout << "4. Keluar" << endl;
        cout << "Pilih: ";
        int choose = 0;
        cin >> choose;
        cout << endl;
        switch(choose){
            case 1:
                cout << "Pilih prioritas: "<<endl;
                cout << "1. Tinggi" << endl;
                cout << "2. Sedang" << endl;
                cout << "3. Rendah" << endl;

                cout << "Pilih:";
                int pilihPrioritas;
                cin >> pilihPrioritas;
                if(pilihPrioritas ==1) {

                    cout <<endl;
                    cout << "Masukkan jumlah nya : ";
                    cin >> jumlahTinggi;
                    masukkanJadwal(prioritasTinggi,jumlahTinggi);
                }else if(pilihPrioritas == 2) {
                    cout <<endl;
                    cout << "Masukkan jumlah nya : ";
                    cin >> jumlahSedang;
                    masukkanJadwal(prioritasSedang,jumlahSedang);

                }else if(pilihPrioritas == 3) {
                    cout <<endl;
                    cout << "Masukkan jumlah nya : ";
                    cin >> jumlahRendah;
                    masukkanJadwal(prioritasRendah,jumlahRendah);
                }
                n = jumlahTinggi + jumlahSedang + jumlahRendah;


                break;
            case 2:
                lihatJadwalPrioritas(prioritasTinggi, prioritasSedang, prioritasRendah);
                break;
            case 3:
                n = jumlahTinggi + jumlahSedang + jumlahRendah;
                if(isEmpty(prioritasTinggi) && isEmpty(prioritasSedang) && isEmpty(prioritasRendah) && timeProccessing <= 0) {
                    cout << "Maaf kegiatan tidak ada" << endl;
                }else {
                    while(Head(prioritasTinggi) != NIL || Head(prioritasSedang) != NIL || Head(prioritasRendah) != NIL ) {



                        if((Head(prioritasTinggi) != NIL )  && (timeProccessing == 0 || timeProccessing % PRIOUP != 0) ) {
                            proccessPrioritas(prioritasTinggi, prioritasSedang, prioritasRendah);

                        }else {
                            if(Head(prioritasSedang) != NIL) {
                                while(Head(prioritasSedang) != NIL) {
                        
                                    gabungQueue(prioritasTinggi, prioritasSedang);

                                }
                            }
                            if(Head(prioritasRendah) != NIL) {
                                while(Head(prioritasRendah)  != NIL) {
                             
                                    gabungQueue(prioritasSedang, prioritasRendah);
                                

                                }

                            }
                            quickJobPrioritas(prioritasTinggi, prioritasSedang, prioritasRendah);

                        }

                    }
                    
                  
                  

                    cout << "Total around time: " <<avrgTotalAroundTime(totalTurnAroundTime, n) << endl;
                    cout << "Total waiting time: " << avrgTotalWaitingTime(totalWaitingTime, n)<< endl;
                }

                break;
            case 4 :
                stillChoose = false;
                cout << "Terimakasih sudah membuat jadwal untuk lord rangga" << endl;
                break;
            default :
                break;
        }
    }
    return 0;
}
