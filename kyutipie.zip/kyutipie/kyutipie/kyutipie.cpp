//
//  kyutipie.cpp
//  kyutipie
//
//  Created by Abdul Azis Al Ayubbi on 10/01/23.
//

#include "kyutipie.hpp"
int timeProccessing = 0;
int prevBurstTime = 0;
float totalWaitingTime = 0;
float totalTurnAroundTime = 0;
int n = 0;
bool isEmpty(Queue Q){
    return Head(Q) == NIL && Tail(Q) == NIL;
}
Queue createQueue() {
    Queue job;
    Head(job) = NIL;
    Tail(job) = NIL;
    return job;
}
void enqueue(Queue &Q, address P) {
    if(isEmpty(Q)) {
        Head(Q) = P;
        Tail(Q) = P;
    }else {
        next(Tail(Q)) = P;
        Tail(Q) = P;
    }
}
void dequeue(Queue &Q, address &P){
    if(isEmpty(Q)) {
        cout << "Job tidak ada";
    }else if(Head(Q) == Tail(Q)) {
        P = Head(Q);
        Head(Q) = NIL;
        Tail(Q) = NIL;
    }
    else {
        P = Head(Q);
        Head(Q) = next(Head(Q));
        next(P) = NIL;
    }
}

void proccessPrioritas(Queue &prioritasTinggi, Queue &prioritasSedang, Queue &prioritasRendah) {
    address P = Head(prioritasTinggi);
    while(P != NIL && (timeProccessing == 0 || timeProccessing % PRIOUP != 0)) {
        address prioritasJob = Head(prioritasTinggi);
        while(prioritasJob != NIL ) {
            if(info(P).burstTime > 0) {
                cout << " Burst time :  " << info(prioritasJob).burstTime ;
            }
           
     

            prioritasJob = next(prioritasJob);
        }
        cout << endl;
        if(info(P).burstTime < QUANTUM) {
            totalWaitingTime += info(P).waitingTime;
            timeProccessing += info(P).burstTime;
            info(P).turnAroundTime = timeProccessing;
            totalTurnAroundTime += timeProccessing;
            prevBurstTime = info(P).burstTime;
            P = next(P);
            address savePrevJobs = NIL;
            dequeue(prioritasTinggi, savePrevJobs);
            prioritasJob = Head(prioritasTinggi);
            while(prioritasJob != NIL) {
                info(prioritasJob).waitingTime += prevBurstTime;
                prioritasJob = next(prioritasJob);
            }
            prioritasJob = Head(prioritasSedang);
            while(prioritasJob != NIL) {
                info(prioritasJob).waitingTime += prevBurstTime;
                prioritasJob = next(prioritasJob);
            }
            prioritasJob = Head(prioritasRendah);
            while(prioritasJob != NIL) {
                info(prioritasJob).waitingTime += prevBurstTime;
                prioritasJob = next(prioritasJob);
            }
        }else {

            timeProccessing += QUANTUM;
            prevBurstTime = QUANTUM;
            info(P).burstTime -= QUANTUM;
            P = next(P);
            address savePrevJobs = NIL;
            dequeue(prioritasTinggi, savePrevJobs);
            prioritasJob = Head(prioritasTinggi);
            while(prioritasJob != NIL) {
                info(prioritasJob).waitingTime += QUANTUM;
                prioritasJob = next(prioritasJob);
            }
            prioritasJob = Head(prioritasSedang);
            while(prioritasJob != NIL) {
                info(prioritasJob).waitingTime += QUANTUM;
                prioritasJob = next(prioritasJob);
            }
            prioritasJob = Head(prioritasRendah);
            while(prioritasJob != NIL) {
                info(prioritasJob).waitingTime += QUANTUM;
                prioritasJob = next(prioritasJob);
            }
            enqueue(prioritasTinggi, savePrevJobs);


        }
    }


}

void quickJobPrioritas(Queue &prioritasTinggi, Queue &prioritasSedang, Queue &prioritasRendah){
    address P = Head(prioritasTinggi);
    address prioritasJob = Head(prioritasTinggi);

    while(prioritasJob != NIL) {
        if(info(P).burstTime > 0) {
            cout << " Burst time :  " << info(prioritasJob).burstTime ;
 
        }
            
        prioritasJob = next(prioritasJob);
    }
    cout << endl;
    if(info(P).burstTime < QUANTUM) {
        totalWaitingTime += info(P).waitingTime;
        timeProccessing += info(P).burstTime;
        info(P).turnAroundTime = timeProccessing;
        totalTurnAroundTime += timeProccessing;
        prevBurstTime = info(P).burstTime;
        P = next(P);
        address savePrevJobs = NIL;
        dequeue(prioritasTinggi, savePrevJobs);
        prioritasJob = Head(prioritasTinggi);

        while(prioritasJob != NIL) {
            info(prioritasJob).waitingTime += prevBurstTime;
            prioritasJob = next(prioritasJob);
        }

        prioritasJob = Head(prioritasSedang);
        while(prioritasJob != NIL) {
            info(prioritasJob).waitingTime += prevBurstTime;
            prioritasJob = next(prioritasJob);
        }
        prioritasJob = Head(prioritasRendah);

        while(prioritasJob != NIL) {
            info(prioritasJob).waitingTime += prevBurstTime;
            prioritasJob = next(prioritasJob);
        }


    }else {
        timeProccessing += QUANTUM;
        prevBurstTime = QUANTUM;
        info(P).burstTime -= QUANTUM;
        P = next(P);
        address savePrevJobs = NIL;
        dequeue(prioritasTinggi, savePrevJobs);
        prioritasJob = Head(prioritasTinggi);
        while(prioritasJob != NIL) {
            info(prioritasJob).waitingTime += QUANTUM;
            prioritasJob = next(prioritasJob);
        }
        prioritasJob = Head(prioritasSedang);
        while(prioritasJob != NIL) {
            info(prioritasJob).waitingTime += QUANTUM;
            prioritasJob = next(prioritasJob);
        }
        prioritasJob = Head(prioritasRendah);
        while(prioritasJob != NIL) {
            info(prioritasJob).waitingTime += QUANTUM;
            prioritasJob = next(prioritasJob);
        }
        enqueue(prioritasTinggi, savePrevJobs);


    }
}

address createElementJob(infotype job) {
    address jobs = new Job;
    info(jobs) = job;
    next(jobs) = NIL;
    return jobs;
}
void masukkanJadwal(Queue &job, int n ){
    cout << "Masukkan jadwal lord rangga " << endl;
  
    
    for(int i = 0; i < n; i++) {
        infotype jobs;
        printf("Masukkan ID Kegiatan %d: ", i+1);
        cin >> jobs.id;
        printf("Masukkan Burst Time Kegiatan ");
        cin >> jobs.burstTime;
        address j  = createElementJob(jobs);
        
        enqueue(job,j );
        
    }
}
void lihatJadwal(Queue job) {
   
    if(isEmpty(job)){
        cout << "Pekerjaan kosong";
    }else {
        address P = Head(job);
        int count = 1;
        while(P != NIL) {
            cout << "Jadwal Lord Rangga: " << count;
            
            cout << "ID: " <<  info(P).id << endl;
            cout << "Burst time: " << info(P).burstTime << endl;
            cout << "Waiting time: " << info(P).waitingTime << endl;
            cout << "Turn around time" << info(P).turnAroundTime << endl;
           
            P = next(P);
        }
    }
    
}
float avrgTotalAroundTime(float totalTurnAroundTime , float n) {
    return (totalTurnAroundTime / n);
}
float avrgTotalWaitingTime(float totalWaitingTime, float n) {
    return (totalWaitingTime / n);
}
void lihatJadwalPrioritas(Queue prioritasTinggi, Queue prioritasSedang, Queue prioritasRendah) {
    address P = Head(prioritasTinggi);
    
    
    if((isEmpty(prioritasTinggi) && isEmpty(prioritasSedang) && isEmpty(prioritasRendah)) && timeProccessing <= 0) {
        cout << "Maaf kamu harus mengisi terlebih dahulu jadwalnya untuk lord rangga." << endl;
        cout << "waiting time: " << totalWaitingTime<< endl;
        cout << "turn around time: " << totalTurnAroundTime<< endl;
    }else {
        cout << "Prioritas Tinggi" << endl;
        if(P != NIL) {
            
            while(P != NIL) {
                
                
                
                cout << "ID: " <<  info(P).id << endl;
                cout << "Burst time: " << info(P).burstTime << endl;
                cout << "Waiting time: " << info(P).waitingTime << endl;
                cout << "Turn around time" << info(P).turnAroundTime << endl;
                
                P = next(P);
                
            }
        }else {
            cout << "Prioritas Kosong";
        }
        cout <<endl;
        P = Head(prioritasSedang);
        cout << "Prioritas Sedang" << endl;
        if(P != NIL) {
            
            while(P != NIL) {
                
                
                cout << "ID: " <<  info(P).id << endl;
                cout << "Burst time: " << info(P).burstTime << endl;
                cout << "Waiting time: " << info(P).waitingTime << endl;
                cout << "Turn around time" << info(P).turnAroundTime << endl;
                
                P = next(P);
                
                
            }
        }else {
            cout << "Prioritas Kosong";
        }
        cout <<endl;
        P = Head(prioritasRendah);
        cout << "Prioritas Rendah" << endl;
        if(P != NIL) {
            
            while(P != NIL) {
                
                
                
                cout << "ID: " <<  info(P).id << endl;
                cout << "Burst time: " << info(P).burstTime << endl;
                cout << "Waiting time: " << info(P).waitingTime << endl;
                cout << "Turn around time" << info(P).turnAroundTime << endl;
                
                P = next(P);
                
                
            }
        }
        
        else {
            cout << "Prioritas Kosong" << endl;
        }
        
        
    }
}

void gabungQueue(Queue &prioritas1, Queue &prioritas2 ){
   
        address p;
        while (Head(prioritas2) != NIL) {
            dequeue(prioritas2, p);
            enqueue(prioritas1, p);
        }

}

