//
//  kyutipie.hpp
//  kyutipie
//
//  Created by Abdul Azis Al Ayubbi on 10/01/23.
//

#ifndef kyutipie_hpp
#define kyutipie_hpp

#include <stdio.h>
#include <iostream>
#define info(P) (P)->info
#define next(P) (P)->next
#define Head(Q) (Q).head
#define Tail(Q) (Q).tail
#define NIL NULL
using namespace std;
const int QUANTUM = 10;
const int PRIOUP  = 30;
extern int timeProccessing;
extern int prevBurstTime;
extern float totalWaitingTime;
extern float totalTurnAroundTime;
extern int n;
struct infotype{
    string id;
    int burstTime;
    int waitingTime = 0;
    int turnAroundTime = 0;
};
typedef struct Job *address;
struct Job {
    infotype info;
    address next;
};
struct Queue {
    address head,tail;
};
bool isEmpty(Queue Q);
Queue createQueue();
void enqueue(Queue &Q, address P) ;
void dequeue(Queue &Q, address &P);
void masukkanJadwal(Queue &job, int n );
void lihatJadwalPrioritas(Queue prioritasTinggi, Queue prioritasSedang, Queue prioritasRendah);
void proccessPrioritas(Queue &prioritasTinggi, Queue &prioritasSedang, Queue &prioritasRendah);
void quickJobPrioritas(Queue &prioritasTinggi, Queue &prioritasSedang, Queue &prioritasRendah);
float avrgTotalAroundTime(float totalTurnAroundTime , float n);
float avrgTotalWaitingTime(float totalWaitingTime, float n) ;
void gabungQueue(Queue &prioritas1, Queue &prioritas2 );
#endif /* kyutipie_hpp */
